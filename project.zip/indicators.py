print('indicators placeholder')
